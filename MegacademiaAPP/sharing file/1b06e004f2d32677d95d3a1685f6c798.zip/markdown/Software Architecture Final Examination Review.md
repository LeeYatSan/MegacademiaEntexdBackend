---
title: Software Architecture Final Examination Review
tags:
- Software Architecture
categories: 
- Software Architecture
copyright: true
comments: true
lang: zh-Hans
updated: 
sticky: 0
---

This article record some important concepts of Software Architecture.

![Software Architecture](https://www.google.com/imgres?imgurl=https%3A%2F%2Fstorage.googleapis.com%2Fnewtechways%2Fimages%2Farch-phil.png&imgrefurl=https%3A%2F%2Fwww.newtechways.com%2Fpages%2Farchitecture.jsp&docid=UcmGi-zusUGL7M&tbnid=zFz8dbdsyk1MCM%3A&vet=12ahUKEwjh1-qL_vbiAhVLzKQKHRIpCZ44yAEQMyhjMGN6BAgBEGQ..i&w=1054&h=670&bih=939&biw=1680&q=Software%20Architecture%20cover&ved=2ahUKEwjh1-qL_vbiAhVLzKQKHRIpCZ44yAEQMyhjMGN6BAgBEGQ&iact=mrc&uact=8#h=670&imgdii=zFz8dbdsyk1MCM:&vet=12ahUKEwjh1-qL_vbiAhVLzKQKHRIpCZ44yAEQMyhjMGN6BAgBEGQ..i&w=1054) 
<!--more-->

# Introduction  
## 为什么需要软件体系结构   
随着软件系统规模越来越大、越来越复杂，用户需求越复杂，软件变化越频繁，对软件质量的要求也越来越高。**对于大规模复杂软件系统来说，对总体的系统结构设计和规格说明比起计算的算法和数据结构的选择已经变得明显重要得多**。  
  
> **系统 = 服务 + 服务总线**  
  
### 面向服务的计算(Service Oriented Computing, SOC)  
面向服务的计算其重点之一就是以标准的方式支持系统的开放性，进而使相关技术与系统具有长久的生命力。
  
### 面向服务的体系结构(Service Oriented Architecture, SOA)  
SOA 是一个组件模型，它将应用程序的不同功能单元（称为服务）进行拆分，并通过这些服务之间定义良好的接口和契约联系起来。**接口是采用中立的方式进行定义的，它应该独立于实现服务的硬件平台、操作系统和编程语言**。这使得构建在各种各样的系统中的服务可以以一种统一和通用的方式进行交互。  
这种具有中立的接口定义（没有强制绑定到特定的实现上）的特征称为**服务之间的松耦合**。松耦合系统的好处有两点，一点是它的灵活性，另一点是，当组成整个应用程序的每个服务的内部结构和实现逐渐地发生改变时，它能够继续存在。与之相反，紧耦合意味着应用程序的不同组件之间的接口与其功能和结构是紧密相连的，因而当需要对部分或整个应用程序进行某种形式的更改时，它们就显得非常脆弱。  
对松耦合的系统的需要来源于业务应用程序需要根据业务的需要变得更加灵活，以适应不断变化的环境，比如经常改变的政策、业务级别、业务重点、合作伙伴关系、行业地位以及其他与业务有关的因素，这些因素甚至会影响业务的性质。我们称能够灵活地适应环境变化的业务为按需（On demand）业务，在按需业务中，一旦需要，就可以对完成或执行任务的方式进行必要的更改。  
虽然面向服务的体系结构不是一个新鲜事物，但它却是更传统的面向对象的模型的替代模型，**面向对象的模型是紧耦合的**，已经存在二十多年了。虽然基于 SOA 的系统并不排除使用面向对象的设计来构建单个服务，但是其整体设计却是面向服务的。由于它考虑到了系统内的对象，所以**虽然 SOA 是基于对象的，但是作为一个整体，它却不是面向对象的**。不同之处在于接口本身。SOA 系统原型的一个典型例子是通用对象请求代理体系结构（Common Object Request Broker Architecture，CORBA），它已经出现很长时间了，其定义的概念与 SOA 相似。  
然而， SOA 已经有所不同了，因为它依赖于一些更新的进展，这些进展是以**可扩展标记语言（eXtensible Markup Language，XML）为基础的**。通过使用基于XML（标准通用标记语言的子集） 的语言（称为 Web 服务描述语言（Web Services Definition Language，WSDL））来描述接口，服务已经转到更动态且更灵活的接口系统中，非以前 CORBA 中的接口描述语言（Interface Definition Language，IDL）可比了。  

  
### 软件即服务(Software-as-a-Service, SaaS)  
指通过**网络**提供软件服务的模式，SaaS模式下厂商将应用软件统一部署在自己的服务器上，客户可以根据自己实际需求，通过互联网向厂商定购所需的应用软件服务，按定购的服务多少和时间长短向厂商支付费用，并通过互联网获得厂商提供的服务。  
传统模式下，厂商通过License将软件产品部署到企业内部多个客户终端实现交付。**SaaS定义了一种新的交付方式**，也使得软件进一步回归服务本质。企业部署信息化软件的本质是为了自身的运营管理服务，软件的表象是一种业务流程的信息化，本质还是第一种服务模式，SaaS 改变了传统软件服务的提供方式，减少本地部署所需的大量前期投入，进一步突出信息化软件的服务属性，或成为未来信息化软件市场的主流交付模式。   
  
## 什么是软件体系结构   
> **Software Architecture(软件体系结构) = Components(组件) + Connectors(连接件) + Constrains(约束)**  
  
软件体系结构在组件和组件间的交互层面上定义了系统，并体现了需求和构建系统的元素之间的联系，而且明确了如规模、容量、吞吐量、一致性和兼容性等系统级特性。  
  
- **Components：**定义了计算的核心，例如过滤器、数据库、对象、过程、服务......
- **Connectors：**是组件间交互的介质，如进程调用、管道、RPC......
- **Properties：**明确了构建和分析的信息，如签名.......  
    
## 软件体系结构的研究活动  
### 软件体系结构描述性语言(ADL)  
ADL提供了具体的语法与刻画体系结构的概念框架，是支持体系结构描述和推理的形式化语言。它提供一种规范化的体系结构描述，使得体系结构的自动化分析变得可能。
  
## 体系结构描述与表示  
![体系结构描述与表示](Software Architecture Final Examination Review/1.png)  
   
# Software Architecture Style  
软件体系结构风格是**描述特定领域中软件系统家族的组织方式的惯用模式**，反映了领域中众多系统所**共有的结构**和**语义特性**，并指导如何将各个模块和子系统有效地组织成一个完整的系统。  
  
> **Architecture Style = {Components / Connectors vocabulary, Topology, Semantic Constrains}**  
  
**软件体系结构风格种类：**  
![软件体系结构风格种类](Software Architecture Final Examination Review/2.png)  
  
**使用软件体系结构风格的好处：**  
![软件体系结构风格种类](Software Architecture Final Examination Review/3.png)  
   
## 数据流体系结构风格(Data Flow Style)  
![数据流体系结构风格](Software Architecture Final Examination Review/4.png)  
  
### 数据流体系结构风格特征  
- 数据的可用性决定着处理单元是否执行
- 系统结构由数据在各处理之间的有序移动决定
- 在纯数据流系统中，处理之间除了数据交换没有任何其他的交互  

### 数据流体系结构风格的架构  
![数据流体系结构风格的架构1](Software Architecture Final Examination Review/5.png)    
![数据流体系结构风格的架构2](Software Architecture Final Examination Review/6.png)    
  
### 数据流形状
数据流风格的数据流一般是按任意形状进行流动的，但我们最主要研究的是近似线性的数据流和是有限循环的数据流。  
![数据流形状](Software Architecture Final Examination Review/7.png)   
  
### 数据流 VS 控制流  
- **数据流：**主要问题是数据如何在运算单元之间流动，我们关心的是数据是否可用、转换、延时......
- **控制流：**主要问题是控制点如何在程序或者系统之间流动，数据可能跟着控制走，但不能起到推动系统运转的作用。控制流关注的核心是计算顺序。

### 三种典型的数据流风格  
  
- 批处理(Batch Sequential) 
- 管道-过滤器(Pipe-and-Filter) 
- 过程控制(Process Controlling)
  
#### 批处理(Batch Sequential)  
![批处理风格结构](Software Architecture Final Examination Review/8.png)  
  
批处理的每一个处理步骤都是一个独立的程序，只有完成前一步后，下一步才能开始。同时，数据必须是完整的，以整体的方式传递。

> 应用场景：
> 程序编译  
> 辅助的计算机软件工程(CASE)   
    
##### 批处理风格模型  
  
- 基本构件：独立的应用程序
- 连接件：某种类型的媒质
- 拓扑结构：连接件定义相应的数据流图，表达拓扑结构  
   
#### 管道-过滤器(Pipe-and-Filter)  
![管道-过滤器1](Software Architecture Final Examination Review/9.png)  
  
过滤器递增地读取和消费数据流  
  
![管道-过滤器2](Software Architecture Final Examination Review/10.png)  
  
过滤器通过计算和增加信息来丰富数据；通过浓缩(Distilling)和删减来精炼(Refine)数据；通过改变数据表现方式来转化数据；过滤器还能将一个数据流分解成多个数据流或者将多个数据流合并为一个数据流。  
  
![管道-过滤器3](Software Architecture Final Examination Review/11.png)  
  
> 应用场景：
> 数据源不断产生，系统需要对这些数据进行若干处理（分析、计算、转换等），此时可以将系统分解为几个序贯的处理步骤，这些步骤之间由数据流连接，一个步骤的输出是另一个步骤的输入。每一个步骤由一个过滤器构件实现，步骤之间的数据传输由管道负责。  
  
##### 管道-过滤器风格模型  
  
- 基本构件：过滤器，用来处理数据流。一个过滤器封装了一个处理步骤，数据源点和数据终点可以看作是特殊的过滤器。**过滤器之间相互独立**，过滤器之间没有上下文信息，不保留状态，对其他过滤器无任何了解。
- 连接件：管道，用来连接一个源和一个目的过滤器。**数据流在管道内单向流动**。管道还可能具有缓冲区。**同时管道的先后顺序不影响输出结果**。不同的管道内流动的数据流可能具有不同的数据格式。
- 拓扑结构：连接件定义相应的数据流图，表达拓扑结构
  
##### 管道-过滤器优缺点  
![管道-过滤器4](Software Architecture Final Examination Review/12.png)  

  
#### 批处理 VS 管道-过滤器  
##### 相同点  
都是把任务分解为一系列固定顺序的计算单元，彼此之间只通过数据传递交互
![批处理 VS 管道-过滤器1](Software Architecture Final Examination Review/13.png)  
  
##### 不同点  
![批处理 VS 管道-过滤器2](Software Architecture Final Examination Review/14.png)   

## 调用/返回体系结构风格(Call/Return style)  
采用调用/返回体系结构的系统通常具有一个包含一个用于执行调用操作的主线程的运作模型(Activation Model)。  
  
### 调用/返回体系结构风格模型  
- 主程序/子过程
- OO和抽象数据类型
- 层次结构
- C/S结构  
  
#### 主程序/子过程(Main Program and Subroutines)  
主程序/子过程本质上是**将大系统分解为若干模块（模块化），主程序调用这些模块实现完整的系统功能**。  
所有程序代码均包含在一个主程序文件夹中，从功能的观点设计系统，典型特点是结构化设计与逐步精细化。同时，它具有层次结构，逐层分解：它基于“定义-使用”的关系，以及将过程调用作为交互机制，子过程的正确性依赖于子过程的调用。   
但由于逻辑不清、无法复用、难以与其他代码合并、难以修改以及难以测试待定部分的代码等缺点，不适用于大型程序。  
![主程序/子过程1](Software Architecture Final Examination Review/15.png)   
  
- 基本构件：主程序、子过程。主程序和子过程，层次化地分解一个程序。
- 连接件：调用-返回机制：每个构件从父级构件中获得控制权和数据，并将它们传递给子构件。
- 拓扑结构：层次化结构
 
##### 过程（函数）调用机制  
![主程序/子过程2](Software Architecture Final Examination Review/16.png)   

##### 管道 VS 过程  
![主程序/子过程3](Software Architecture Final Examination Review/17.png)   
  
##### 主程序/子过程优缺点  
![主程序/子过程4](Software Architecture Final Examination Review/18.png)  
  
#### 面向对象风格(Object-Oriented, OO)/抽象数据类型(Abstract Data Type, ADT)  
系统被看作为对象的集合，每个对象都有一个自己的功能集，数据和作用在数据上的操作被封装成抽象数据类型——对象。  
     
**核心特点：封装(Encapsulation)**  
 
- 基本构件：类和对象。
- 连接件：对象之间通过消息和方法实现交互。  
  
##### OO特性  
![OO1](Software Architecture Final Examination Review/19.png)  

##### OO优缺点  
![OO2](Software Architecture Final Examination Review/20.png)  
  
#### 分层风格(Layered System)  
一个分层的系统被组织成若干个层次，每个层次由一系列构件组成。下层构件向上层构件提供服务，上层构件则被看作是下层构件的客户。  
  
![分层风格1](Software Architecture Final Examination Review/21.png)  
  
- 基本构件：各层次内部包含的构件。
- 连接件：层间交互的协议。
- 拓扑结构：分层
- 拓扑约束：对相邻层间的交互的约束（集中部署、分布式部署）。
   
##### 分层原则  
**不同层次处于不同的抽象级别，越靠近底层（硬件与OS），抽象级别越高，越通用；越靠近顶层（用户），抽象级别越低，越具体**。  
    
- 分离关注：尽可能小粒度地将应用程序分解成一个个能够覆盖功能需求的独一无二的特性
- 抽象：专注于本质而排除不相关因素
- 隐藏：进行访问控制  
   
##### 分层结构优缺点  
优点： 
![分层风格2](Software Architecture Final Examination Review/22.png)  
  
缺点：  
![分层风格3](Software Architecture Final Examination Review/23.png)  
     
#### 客户机/服务器风格(C/S style)  
##### 两层C/S  
![C/S1](Software Architecture Final Examination Review/24.png)  
  
##### 三层C/S  
![C/S2](Software Architecture Final Examination Review/25.png)  

## 以数据为中心体系结构风格(Data Centered）  
将数据存储在注册表等文件中，形成共享仓库，为系统运行起到集中的资源配置、管理和控制调度的作用。  
  
> 例子：
> 剪贴板

### 以数据为中心体系结构风格模型  
  
> 两种主要的交互机制  
1. **数据库方式**：输入流中事务类型触发需执行的过程。
2. **黑板结构**：中心数据节后的当前状态出发并选择需要执行的过程。 
  
#### 仓库风格(Repository)  
仓库是存储和维护数据的中心场所。 
  
![仓库风格](Software Architecture Final Examination Review/26.png)  
  
- 基本构件：仓库风格有两种不同的构件：**中心数据结构**，表示当前的数据的状态；**一组对中心数据进行操作的独立构件**。
- 连接件：仓库与独立构件之间的交互。
  
#### 黑板风格(Black Board)   
![黑板风格1](Software Architecture Final Examination Review/27.png)  
![黑板风格2](Software Architecture Final Examination Review/28.png)  
![黑板风格3](Software Architecture Final Examination Review/29.png)  

> 应用场景：
> 适合于解决无确定性解的问题
> 如：自然语言处理系统、语音处理系统、模式识别、图形处理等

- **知识源**：独立的求解程序，它是描述某个独立领域问题的知识及其处理方法的数据库。将待解决的问题分为若干子问题，每个子问题由一个独立的知识源进行计算。知识源包含独立的领域知识。多个知识源之间只能通过黑板交换知识——通过黑板的读写操作来完成交换。知识源具有“条件-动作”的形式，当条件满足时，知识源被触发，其动作部分增加活修改黑板上的内容。
- **控制器**：根据当前状态决定知识元的执行次序。控制器用来控制和协调所有知识源，使其协同地解决问题。它了解每个知识源的能力，实时决策解决问题的步骤。控制器时刻监视黑板状态变化，对黑板上信息的当前状态进行判断和评价。当黑板的状态满足了知识源的执行条件时，该知识源被控制器触发并进行计算，然后将结果更新到黑板上。这种更新导致其他知识源参与计算并更新黑板，直到找到问题解为止。
- **黑板**：保存求解状态。     
    
![黑板风格4](Software Architecture Final Examination Review/30.png) 
    
##### 黑板风格优缺点  
![黑板风格5](Software Architecture Final Examination Review/31.png)  
    
#### 仓库风格 VS 黑板风格  
- 仓库风格：操作执行顺序是预先确定的。
- 黑板风格：黑板的状态出发进一步的操作，适合于解决无确定性解的问题。
  
## 虚拟机(Virtual Machine)  
虚拟机风格的系统在语义层上提供了其他技术。  
  
### 虚拟机风格模型  
#### 解释器风格(Interpreter)  
解释器是一个用来执行其他程序的程序。它通常用来在程序语言定义的计算和有效硬件操作确定的计算之间建立对应和联系。    
  
![解释器风格1](Software Architecture Final Examination Review/32.png)  
  
- 基本构件：**解释器引擎(Interpretation Engine)**和**内存**，其中内存中包含被解释的源代码、解释器引擎当前的控制状态的表示和程序当前执行状态的表示。
- 连接件：迎来对存储区的数据访问。  
  
##### 解释器 VS 编译器  
![解释器风格2](Software Architecture Final Examination Review/33.png)  
解释器的执行速度要慢于编译器产生的目标代码的执行速度，但却低于编译器“编译+链接+执行”的总时间。同时，由于解释器通常省略了链接与编译的步骤，从而降低编程时间。解释器执行速度之所以慢，是因为每次解释执行的时候，都需要分析程序的结构，而编译代码则直接执行而无需重复编译。解释器对内存的分配实在解释时才进行的，而编译器则是在编译时进行，因此运行时直接将程序装入内存并执行即可。 
  
##### 解释器的优缺点  
![解释器风格3](Software Architecture Final Examination Review/34.png)  
  
#### 基于规则的系统(Rule-based Systems)  
基于规则的系统是一个使用模式匹配搜索来寻找规则并在正确的时候应用正确的逻辑知识的虚拟机。  
![基于规则的系统1](Software Architecture Final Examination Review/36.png)  
![基于规则的系统2](Software Architecture Final Examination Review/35.png)  
![基于规则的系统3](Software Architecture Final Examination Review/37.png)  
  
每一条规则都由两部分组成：**IF**：规则的前提或条件；**THEN**：规则的结论或触发行为。  
  
##### 基于规则的系统的优缺点  
![基于规则的系统4](Software Architecture Final Examination Review/38.png)  
  
#### 解释器 VS 基于规则的系统  
![解释器 VS 基于规则的系统1](Software Architecture Final Examination Review/39.png)  
  
## 事件系统体系结构风格(Event Systems)   

- **消息(Message)**：消息是具有特定含义的数据，是对象之间传递的内容等信息。  
- **事件(Event)**：能够激活对象功能的动作，当发生这种动作后将给所设计对象发送一个消息，对象便可执行相应的功能。  
    
### 基本结构  
- 基本构件：过程或函数，充当事件源或事件处理器的角色。
- 连接件：事件过程绑定：过程（事件处理器）向特定的事件进行注册；构件（事件源）发布事件；当某些事件被发布时，向其注册的过程被**隐式调用**，调用的次序是不确定的。   
  
### 显式调用(Explicit Invocation) VS 隐式调用(Implicit Invocation)   
#### 显式调用  
各个构件之间互动是由显性调用函数或者程序完成的。调用过程与次序是固定的、预先设定的。
![显式调用](Software Architecture Final Examination Review/40.png)  
  
#### 隐式调用  
隐式调用是指一个事件隐式地导致其他模块的过程的调用。隐式调用的思想是不直接调用一个过程。一个组件可以广播一些事件，系统中的其他构件可以注册自己感兴趣的事件，并将自己的某个过程与相应的事件进行关联。当一个事件被发布时，系统自动调用该事件中注册的所有过程。    
  
![隐式调用](Software Architecture Final Examination Review/41.png)  
   
这种风格的主要特点是，事件的触发者不知道哪些构件会被这些事件影响，并相互保持独立。即不能假定构件的处理顺序，甚至不知道哪些过程会被调用。各个构件之间彼此无连接关系，各自独立存在，通过事件的发布和注册实现联系。  
  
### 事件系统的调度机制  
当事件发生时，已向此事件注册过的过程被激发并执行。  
  
#### 事件系统调用的方法  
  
![事件系统调用的方法](Software Architecture Final Examination Review/46.png)  
  
##### 无派遣模块的事件管理器(EventManager without a central dispatcher module)    
无派遣模块的事件管理器被称为“被观察者/观察者”(Observable/Observer)，每一个模块都允许其他模块向自己所能发送的某些消息表明兴趣。当某一模块发出某一事件时，它自动地将这些事件发布给那些曾经向自己注册过的事件模块。  
  
![无派遣模块的事件管理器](Software Architecture Final Examination Review/42.png)  
  
##### 带有派遣模块的事件管理器(EventManager with separated dispatcher module)
**事件派遣模块**：负责接收到来的事件并派遣它们到其他模块；派遣器应该决定怎样派遣，有两种派遣策略：  
- **广播式(All Broadcasting)**：派遣模块将事件广播到所有模块，但只有感兴趣的模块才会去取事件并触发自身的行为。这是一种无目的广播，靠接受者自行决定是否加一处理或简单抛弃。
  
![广播式](Software Architecture Final Examination Review/43.png)  
  
- **选择广播式(Selected Broadcasting)**：派遣模块将事件送到那些已经注册了的模块中。   
    1. **点对点模式(Point-to-Point)**：基于**消息队列**。系统安装并配置一个队列管理器，并定义一个命名的消息队列。某个应用向消息队列注册，以监听并处理放置在队列里的事件。其他应用连接到该队列并向其中发布事件。队列管理器存储这些消息，直到接收端的应用连接到队列，取回这些消息并加以处理。**消息只能被唯一消费者所消费**，消费后消息从队列中删除。
    2. **发布-订阅模式(Publish-Subscribe)**：一个事件可以被多个订阅者消费，事件在发送给订阅者后，并不会马上从 topic 中删除，topic 会在事件过期后自动将其删除。
  
![选择广播式1](Software Architecture Final Examination Review/44.png)   
![选择广播式2](Software Architecture Final Examination Review/45.png)  
   
### 事件系统的优缺点  
#### 优点  
![事件系统的优缺点1](Software Architecture Final Examination Review/47.png)  
  
#### 缺点  
![事件系统的优缺点2](Software Architecture Final Examination Review/48.png)  
  
# Software Architecture Modeling  
模型(Model)是系统、理论或现象的图解性描述（抽象），用来描绘其已知的或推演的特性；它通常具有一组属性以及作用在这组属性上的逻辑或数量关系。  
  
建模的目的在于提供一个理想的论证框架，应用逻辑和数学工具，评估性能，并在多个类似场景下进行推理。  
  
> 模型化的三种方法： 
> **图形化模型**：SA模型的多视图表示(Multi-view graphical model)
> **形式化模型**：SA描述语言(Formal architecture description language, ADL)
> **文档化模型**：记录和整理软件体系结构设计方案的各类细节(Documantation)  
  
**体系结构(Architecture) = 构件(Components) + 连接件(Connectors) + 拓扑结构(Topology) + 约束(Constrains) + 质量(Performance)**  
  
![Modeling 1](Software Architecture Final Examination Review/49.png)  
![Modeling 2](Software Architecture Final Examination Review/50.png)  

## 精确(Precision) VS 准确(Accuracy)  
![精确(Precision) VS 准确(Accuracy)](Software Architecture Final Examination Review/51.png)  
  
## “4+1”视图模型  
“4+1”视图模型从**逻辑视图**、**进程视图**、**物理视图**、**开发视图**和**用例视图**五个不同的视角来描述软件体系结构。每一个视图只关心系统的一个侧面，5个视图结合在一起才能反映系统的软件体系结构的全部内容。  
  
![“4+1”视图模型1](Software Architecture Final Examination Review/52.png)  
  
逻辑视图和开发视图描述系统的**静态**结构，而进程视图和物理视图描述系统的**动态**结构。 
  
### UML的“4+1”视图
![“4+1”视图模型2](Software Architecture Final Examination Review/53.png)  
![“4+1”视图模型3](Software Architecture Final Examination Review/54.png)  
![“4+1”视图模型4](Software Architecture Final Examination Review/55.png)  
![“4+1”视图模型5](Software Architecture Final Examination Review/56.png)  

#### UML 视图种类  
![UML 视图种类1](Software Architecture Final Examination Review/57.png)  
![UML 视图种类2](Software Architecture Final Examination Review/58.png)  
![UML 视图种类3](Software Architecture Final Examination Review/59.png)  
![UML 视图种类4](Software Architecture Final Examination Review/60.png)  
![UML 视图种类5](Software Architecture Final Examination Review/61.png)  
![UML 视图种类6](Software Architecture Final Examination Review/62.png)  
  
# Software Architecture Design  
战术(Tactic)是一种影响控制响应质量属性的设计决策。一系列这样的战术的集合称为体系结构策略(Architecture Strategy)。  
  
## 可用性战术(Availability Tactics) 
可用性战术阻止错误发展成为故障或者把错误的影响限制在一定范围内，从而使修复成为可能。  
  
- 错误检测(Fault Detection)
  - 命令/响应(Ping/echo)
  - 心跳同步(Heartbeat)
  - 异常(Exception)
- 错误修复(Fault Recovery)
  - 投票(Voting)：进程在多个处理器上运行，并进行相同的输入，将输出结果输出到投票器上进行检测。
  - 积极冗余/热重启(Active Redundancy/Hot Restart)：所有组件并行地对事件进行响应，这就意味着它们始终保持一致的状态。但只有一个响应会被使用，其余的响应会被抛弃。
  - 消极冗余/暖重启/双重冗余/三重冗余(Passive Redundancy/Warm Restart/Dual Redundancy/Triple Redundancy)：一个（首要的）组件会对事件进行响应，并通知其他组件更新它们的状态。一旦错误发生，系统必须在恢复前保证备份足够新。
  - 状态重新同步(State Resynchronization)
  - 空闲(Spare)
  - 检查点/回滚(Checkpoint/Rollback)
  - 影子操作(Shadow Operation)：前一个失败的组件会在恢复服务前在一个“影子模式”下运行一小段时间，以确认它能模仿真实工作组件的表现
- 错误阻止(Fault Prevention)
  - 从服务中分离(Removal From Service)
  - 事务(Transcation)
  - 管程(Process Monitor)
  
![可用性战术1](Software Architecture Final Examination Review/63.png)  
![可用性战术2](Software Architecture Final Examination Review/64.png)  
  
## 性能性战术(Performance Tactics)
性能性战术是指在事件到达系统时在约束时间的条件下生成一个响应。  
  
- 资源需求(Resource Demand)
  - 减少进程资源请求
  - 减少活动进程数，控制事件率
  - 控制资源的使用
  - 提升计算效率，减少计算开销
  - 控制执行时间
  - 控制队列大小
- 资源管理(Resource Management)
  - 并行计算，负载均衡
  - 多服务器站点
  - 增加可用资源数
- 资源仲裁(Resource Arbitration)
  - FIFO
  - 固定优先级调度(Fixed-priority Scheduling)
  - 动态优先级调度(Dynamic Priority Scheduling)
    - 轮转(Round Robin)
    - 最早结束优先(Earliest Deadline First)
  - 静态调度(Static Scheduling)
  
![性能性战术1](Software Architecture Final Examination Review/65.png)  
![性能性战术2](Software Architecture Final Examination Review/66.png)  
  
## 可修改性战术(Modifiability Tactics)  
可修改性战术是指控制对于修改发生时的开发实现、测试和部署所需的资金与时间开销。  
  
- 局部化修改(Localize Modifications)
  - 维护语义耦合(Maintain Semantic Coherence)：抽象化通用服务，每个模块职责越单一越好
  - 预期期望的变更(Anticipate Expected Changes)
  - 泛化模块(Generalize The Module)
  - 限制可能的选择(Limit Possible Options)
- 防止变更导致连锁反应(Prevent Ripple Effects)
  - 处理好依赖关系(Dependencies)：接口、抽象类、实现类
  - 隐藏信息(Hiden Information)
  - 维护好已有的接口(Maintain Existing Interfaces)
  - 限制交互路径(Restrict Communication Paths)
  - 引入中间层(Use an Intermediary)
- 推迟实际运算单元的绑定事件(Defer Binding Time)
  - 运行时注册(Runtime Registration)
  - 引入配置文件(Configuration Files)
  - 多态(Polymorphism)
  
![可修改性战术1](Software Architecture Final Examination Review/67.png)  
![可修改性战术2](Software Architecture Final Examination Review/68.png)  
   
## 安全性战术(Security Tactics)  
  
- 抵抗攻击(Resisting Attacks)
  - 对用户身份进行验证(Authenticate Users)
  - 对用户进行授权(Authorize Users)
  - 维护数据的机密性(Maintain Data Confidentiality)：加密(Encryption)
  - 维护数据的完整性(Maintain Integrity)
  - 限制数据暴露(Limit Exposure)
  - 限制访问(Limit Access)
- 监测攻击(Detecting Attacks)
  - 入侵系统检测(Intrusion Detection System)
- 从攻击中恢复(Recovering From Attacks)
  - 状态恢复(Restoring State)
  - 攻击者识别(Attacker Identification)
  
![安全性战术1](Software Architecture Final Examination Review/69.png)  
![安全性战术2](Software Architecture Final Examination Review/70.png)  
  
## 可测试性战术(Testability Tactics)  
可测试性战术指当程序有新功能开发并部署完成时，能够更容易对其进行测试。  
  
- I/O
  - 录制/回放(Record/Playback)：捕获通过接口的信息，并在测试时将这些信息作为输入并输入到测试装置中
  - 将接口从实现中分离(Separate Interface From Implementation)  
  - 专用访问路径/接口(Specialize Access Routes/Interfaces)
- 内部管理(Internal Monitoring)
  - 内建管理器(Built-in Monitors)
  
![可测试性战术1](Software Architecture Final Examination Review/71.png)  
![可测试性战术2](Software Architecture Final Examination Review/72.png)  
  
## 可用性战术(Usability Tactics)  
可用性战术指用户使用系统的简易程度以及系统能为用户所提供的服务支持种类。  
  
- 运行时战术(Runtime Tactics)
  - 支持用户自主(Support User Initiative)
  - 支持系统自主(Support System Initiative)
    - 维护一个任务模型(Maintain a model of the task)
    - 维护一个用户模型(Maintain a model of the user)
    - 维护一个系统模型(Maintain a model of the system)
- 设计时战术(Design-Time Tactics)
  - 将用户接口与其他部分分离(Separate the user interface from the rest of the application)：MVC
  - Presentation-Abstraction-Control(PAC)
    
# Software Quality Attributes  
## 质量属性场景(Quality Attribute Scenarios)
![质量属性场景](Software Architecture Final Examination Review/73.png)  
  
## 质量属性(Quality Attribute)  
### 可用性(Availability)  
![可用性1](Software Architecture Final Examination Review/74.png)  
![可用性2](Software Architecture Final Examination Review/75.png)  
  
### 性能(Performance)  
性能更加关注于事件发生时系统需要多长时间进行响应。  
  
### 可修改性(Modifiability)  
可修改性是指系统易修改从而适应新的需求或采用新的算法、数据结构的能力。  
  
### 安全性(Security)  
安全性是衡量一个系统在向合法用户提供服务的时候抵抗未授权的使用的能力。  
  
安全性由以下属性所确定：  
#### 不可抵赖性(Nonrepudiation)  
不可抵赖性指一个事务（访问或修改数据或服务）都不能被其任意一部分所否认。即一旦你通过因特网发出了某个指令，你不能否认你做了。  
  
#### 机密性(Confidentiality)  
机密性指数据或服务被保护起来以免遭受到未授权的访问。  
  
#### 完整性(Integrity)  
完整性指数据或服务都按照意愿所发布。例如一旦你的成绩被教师所批出，则不能改变。  
  
#### 担保性(Assurance)  
担保是指某个团体或组在一个事务中是用户所希望成为的那种。例如当一个用户发送一个信用卡号到一个网络零售商，则这个零售商就是用户所想的那种对象。  
  
#### 可用性(Availability)  
可用性是指系统能够在合法使用的情况下被使用。  
  
#### 安全审计(Auditing)  
安全审计是指系统会在足以重建活动的级别上跟踪其内部活动的属性。  
  
### 可测试性(Testability)  
可测试性指的是软件能够通过测试来找出其存在的问题。  
  
### 易用性(Usability)  
易用性关注的是用户使用软件来完成对应任务的难易程度以及系统所支持的用户种类的多少。  
  
### 其他属性
![其他属性](Software Architecture Final Examination Review/76.png)  
    
# Software Architecture Evaluation  
## 软件体系结构评价方法  
### 基于场景的软件体系结构分析方法(Scenario-based Architecture Analysis Method, SAAM)  
这个方法最初是用于分析软件体系结构的可修改性的，然而它也非常适用于非功能层面的软件体系结构分析。它建立在使用利益相关者生成的场景来访问体系结构的基础上。  
  
### 软件体系结构权衡分析法(Software Architecture Evaluation Method, ATAM)  
ATAM 是 SAAM 的一种特殊化，它专注于可修改性、性能、可用性和安全性。该方法使用质量属性效应树(Quality Attribute Utility Trees)和质量属性分类(Quality Attribute Categories)进行软件体系结构分析。SAAM 没有显式地指明质量属性之间的交互关系，而 ATAM 则体现了这种关系。因此，ATAM 更加适合于质量属性之间的比较。  
  
ATAM 主要是为了帮助利益相关者说出正确的需求一帮助发掘软件体系结构中潜在的问题。这个方法能够显式地识别并用文档记录所有“折衷”（Tradeoff）。被发现的问题能够在后续的活动中被重点减轻。 
  
**ATAM 不是为了获得精确的分析，而是去发现软件体系结构的确定过程中潜在的风险。**  
  
![其他属性](Software Architecture Final Examination Review/77.png)   
  
#### ATAM 好处  
- 识别风险
- 明确质量属性需求
- 提升软件结构体系文档
- 基于文档的体系结构决策
- 增加利益相关者间的沟通  
  
#### ATAM 步骤  
![ATAM 步骤](Software Architecture Final Examination Review/78.png)   
  
#### 质量效应树(Quality Utility Tree)  
质量效应树是一个自顶向下的工具，用来刻画重要的需求。  
  
![质量效应树](Software Architecture Final Examination Review/79.png)    
  
**(H,H)最重要、最难实现即最关注的内容。**  
  
### 基于复杂场景的 SAAM(SAAM Founded on Complex Scenarios, SAAMCS)   
这个方法将场景的复杂性作为最重要的风险评估因素。  
  
### 基于特定领域整合的拓展 SAAM (Extending SAAM by Integration in the Domain, ESAAMI)  
这个方法将 SAAM 与特定领域以及基于重用的软件开发过程相结合。   
  
### 用于演化以及重用的软件体系结构评估方法(Software Architecture Analysis Method for Evolution and Reusability, SAAMER)  
该方法专注于演化以及重用的质量属性。  
  
### 基于场景的软件体系结构重构(Scenario-Based Architecture Reengineering, SBAR)  
该方法将场景供句话，通过仿真数学模型，以及基于经验的推理来得到质量属性。   
  
### 体系结构级别上的软件维护预测(Architecture Level Predication of Software Maintenance, ALPSM)  
该方法基于场景对软件的可维护性进行分析。  
  
### 软件体系结构评价方法(Software Architecture Evaluation Model, SAEM)  
该方法基于严格且精确的质量需求进行分析。  
  

